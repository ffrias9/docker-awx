---
name: "\U0001F525 Security bug report"
about: How to report security vulnerabilities

---

For all security related bugs, email security@ansible.com instead of using this issue tracker and you will receive a prompt response.

For more information on the Ansible community's practices regarding responsible disclosure, see https://www.ansible.com/security
