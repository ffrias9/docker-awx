# List Fact Scans for a Host Specific Host Scan

Make a GET request to this resource to retrieve system tracking data for a particular scan

You may filter by datetime:

`?datetime=2015-06-01`

and module

`?datetime=2015-06-01&module=ansible`
